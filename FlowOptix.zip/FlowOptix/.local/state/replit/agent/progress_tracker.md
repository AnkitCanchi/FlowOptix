[x] 1. Install the required packages
[x] 2. Restart the workflow to see if the project is working
[x] 3. Migrate Supabase to Replit backend
  [x] 1. Moved AI chat to a server-side Express route (/api/chat) - API key is now server-side only
  [x] 2. Ported Supabase Edge Function (ie-chat) into server/index.ts Express route
  [x] 3. Secured API keys - OPENAI_API_KEY stored in Replit Secrets, never exposed to frontend
  [x] 4. No database tables to migrate (Supabase schema was empty)
  [x] 5. Removed all Supabase code (supabase/ dir, src/integrations/supabase/, @supabase/supabase-js usage)
[x] 4. Verify the project is working - app loads, backend runs on port 3001, Vite on port 5000
[x] 5. Import completed - complete_project_import called
